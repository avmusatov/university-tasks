function [y] = f1pr1(x)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
y = 4*x^3 - 54*x^2;
end

