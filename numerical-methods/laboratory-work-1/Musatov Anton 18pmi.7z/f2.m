function [y] = f2(x)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
y = atan(x.^2+ 1./x) - x;
end

