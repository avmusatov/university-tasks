function [y] = phi2(x)
%UNTITLED12 Summary of this function goes here
%   Detailed explanation goes here
y = atan(x^2+1/x);
end

