function [y] = f1pr2(x)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
y = 12*x^2 - 108*x;
end

