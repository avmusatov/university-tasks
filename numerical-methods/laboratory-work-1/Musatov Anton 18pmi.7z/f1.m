function [y] = f1(x)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
y = x.^4 - 18.*x.^3 - 10;
end

