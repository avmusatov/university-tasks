function [y] = phi2_pr1(x)
%UNTITLED13 Summary of this function goes here
%   Detailed explanation goes here
y = (2*x - 1/x^2)/(1+ (x^2+1/x)^2);
end

