function [y] = f2pr1(x)
%UNTITLED9 Summary of this function goes here
%   Detailed explanation goes here
y = (2*x - 1/x^2)/(1+ (x^2+1/x)^2) - 1;
end

