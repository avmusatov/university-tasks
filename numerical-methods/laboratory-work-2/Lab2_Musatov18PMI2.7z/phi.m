function [y] = phi (Z,x)
    y = Z(2) + Z(1).*x;
end
